-- MySQL dump 10.13  Distrib 8.0.28, for Linux (x86_64)
--
-- Host: localhost    Database: bdGamerepair
-- ------------------------------------------------------
-- Server version       8.0.28-0ubuntu0.20.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `consola`
--

DROP TABLE IF EXISTS `consola`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `consola` (
  `id` int NOT NULL AUTO_INCREMENT,
  `marca` varchar(50) NOT NULL,
  `modelo` varchar(50) NOT NULL,
  `codProprietario` int NOT NULL,
  `pirata` tinyint NOT NULL,
  `acessorio` varchar(200) DEFAULT NULL,
  `consolaReparavel` tinyint NOT NULL,
  `tamanhoHD` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `codProprietario` (`codProprietario`),
  CONSTRAINT `consola_ibfk_1` FOREIGN KEY (`codProprietario`) REFERENCES `proprietario` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `consola`
--

LOCK TABLES `consola` WRITE;
/*!40000 ALTER TABLE `consola` DISABLE KEYS */;
INSERT INTO `consola` VALUES (1,'Naoentendo','NX',1,1,'1 Joystick sujo',1,NULL),(2,'Macrohardware','XCaixa1',2,0,'Nada',1,NULL),(3,'Naoentendo','NX2',3,1,'2 Joysticks',1,NULL),(4,'SÔNIA','PlayAi',4,0,'Nada',1,NULL),(5,'SÔNIA','PlayAi',5,1,'Óculos VR enferrujado',1,NULL),(6,'XCaixa1','NX',1,1,'Nada',1,NULL);
/*!40000 ALTER TABLE `consola` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `peca`
--

DROP TABLE IF EXISTS `peca`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `peca` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nomePeca` varchar(50) NOT NULL,
  `custoPeca` decimal(5,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `peca`
--

LOCK TABLES `peca` WRITE;
/*!40000 ALTER TABLE `peca` DISABLE KEYS */;
INSERT INTO `peca` VALUES (1,'Fonte de alimentação',105.90),(2,'Placa de vídeo',200.00),(3,'Rebimboca da parafuseta',10.90),(4,'Joystick',29.90);
/*!40000 ALTER TABLE `peca` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pecaReparacao`
--

DROP TABLE IF EXISTS `pecaReparacao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pecaReparacao` (
  `id` int NOT NULL AUTO_INCREMENT,
  `codReparacao` int NOT NULL,
  `codPeca` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `codReparacao` (`codReparacao`),
  KEY `codPeca` (`codPeca`),
  CONSTRAINT `pecaReparacao_ibfk_1` FOREIGN KEY (`codReparacao`) REFERENCES `reparacao` (`id`),
  CONSTRAINT `pecaReparacao_ibfk_2` FOREIGN KEY (`codPeca`) REFERENCES `peca` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pecaReparacao`
--

LOCK TABLES `pecaReparacao` WRITE;
/*!40000 ALTER TABLE `pecaReparacao` DISABLE KEYS */;
/*!40000 ALTER TABLE `pecaReparacao` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proprietario`
--

DROP TABLE IF EXISTS `proprietario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `proprietario` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nif` int NOT NULL,
  `nome` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proprietario`
--

LOCK TABLES `proprietario` WRITE;
/*!40000 ALTER TABLE `proprietario` DISABLE KEYS */;
INSERT INTO `proprietario` VALUES (1,303415899,'Vitoxa'),(2,598715899,'Mike Jagger'),(3,587964875,'Rui Cabeludim'),(4,698745354,'Ga Rafinha'),(5,658475215,'Edu Mestre');
/*!40000 ALTER TABLE `proprietario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reparacao`
--

DROP TABLE IF EXISTS `reparacao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reparacao` (
  `id` int NOT NULL AUTO_INCREMENT,
  `reparavel` tinyint NOT NULL,
  `codTecnico` int NOT NULL,
  `codConsola` int NOT NULL,
  `dataEntrada` datetime NOT NULL,
  `dataEstimada` datetime NOT NULL,
  `dataEntrega` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `codTecnico` (`codTecnico`),
  KEY `codConsola` (`codConsola`),
  CONSTRAINT `reparacao_ibfk_1` FOREIGN KEY (`codTecnico`) REFERENCES `tecnico` (`id`),
  CONSTRAINT `reparacao_ibfk_2` FOREIGN KEY (`codConsola`) REFERENCES `consola` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reparacao`
--

LOCK TABLES `reparacao` WRITE;
/*!40000 ALTER TABLE `reparacao` DISABLE KEYS */;
INSERT INTO `reparacao` VALUES (1,1,1,1,'2022-01-10 00:00:00','2022-01-20 00:00:00','2022-01-22 00:00:00'),(2,1,2,1,'2022-01-30 00:00:00','2022-02-02 00:00:00','2022-02-02 00:00:00'),(3,1,3,3,'2022-01-13 00:00:00','2022-01-19 00:00:00','2022-01-20 00:00:00'),(4,0,1,3,'2022-03-10 00:00:00','2022-03-20 00:00:00','2022-03-12 00:00:00'),(5,1,2,5,'2022-04-01 00:00:00','2022-04-10 00:00:00','2022-04-05 00:00:00'),(6,1,3,4,'2022-02-02 00:00:00','2022-02-07 00:00:00','2022-02-07 00:00:00'),(7,1,1,2,'2022-03-12 00:00:00','2022-03-20 00:00:00','2022-03-22 00:00:00');
/*!40000 ALTER TABLE `reparacao` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tecnico`
--

DROP TABLE IF EXISTS `tecnico`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tecnico` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nomeTecnico` varchar(50) NOT NULL,
  `nif` int NOT NULL,
  `custoPorHora` decimal(5,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tecnico`
--

LOCK TABLES `tecnico` WRITE;
/*!40000 ALTER TABLE `tecnico` DISABLE KEYS */;
INSERT INTO `tecnico` VALUES (1,'Rui Boticas',12345678,10.50),(2,'Miguel Cunha',54789631,8.50),(3,'Thiago Oliveira',58796421,9.50);
/*!40000 ALTER TABLE `tecnico` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-04-06 11:30:39